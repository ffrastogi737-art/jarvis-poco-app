# config/__init__.py
import json, os, platform
from pathlib import Path

_CONFIG_PATH = Path(__file__).parent / "api_keys.json"

def _platform_os() -> str:
    """Auto-detect OS when config file is absent."""
    return {"Windows": "windows", "Darwin": "mac", "Linux": "linux"}.get(
        platform.system(), "linux"
    )

def get_config() -> dict:
    try:
        with open(_CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def get_os() -> str:
    """Returns: 'windows' | 'mac' | 'linux'"""
    return get_config().get("os_system", _platform_os()).lower()

def is_windows() -> bool: return get_os() == "windows"
def is_mac()     -> bool: return get_os() == "mac"
def is_linux()   -> bool: return get_os() == "linux"

def audio_device(kind: str):
    """Device index for 'input' (mic) or 'output' (earphones) from config, else None = Windows default.
    Saved by choose_audio.py as a name, because device numbers change when USB is replugged."""
    name = (get_config().get(f"{kind}_device") or "").strip().lower()
    if not name:
        return None
    try:
        import sounddevice as sd
        devices = sd.query_devices()
        matches = [i for i, d in enumerate(devices)
                   if name in d["name"].lower() and d[f"max_{kind}_channels"] > 0]
        # Same name exists once per Windows audio API; prefer the default one (MME resamples for us).
        for i in matches:
            if devices[i]["hostapi"] == sd.default.hostapi:
                return i
        return matches[0] if matches else None   # unplugged -> Windows default
    except Exception:
        return None
