"""Choose which mic (input) and earphones/speaker (output) MARK L uses.
Saves the device names to config/api_keys.json. Run: double-click choose_audio.bat
"""
import json
from pathlib import Path

import sounddevice as sd

CONFIG = Path(__file__).parent / "config" / "api_keys.json"
RATE = 16000  # same rate MARK L sends to Gemini, so a passing test means MARK L works too


def pick(kind: str, label: str) -> str:
    devices = sd.query_devices()
    default = sd.default.device[0 if kind == "input" else 1]
    # One entry per device: the same device is listed once per Windows audio API.
    options = [(i, d["name"]) for i, d in enumerate(devices)
               if d["hostapi"] == sd.default.hostapi and d[f"max_{kind}_channels"] > 0]
    print(f"\n=== {label} ===")
    print("  0. Windows default")
    for n, (i, name) in enumerate(options, 1):
        print(f"  {n}. {name}" + ("   <- abhi default" if i == default else ""))
    while True:
        choice = input("Number likho aur Enter dabao (sirf Enter = Windows default): ").strip()
        if choice in ("", "0"):
            return ""
        if choice.isdigit() and 1 <= int(choice) <= len(options):
            return options[int(choice) - 1][1]
        print("Galat number, phir se try karo.")


def device_index(name: str, kind: str):
    if not name:
        return None
    for i, d in enumerate(sd.query_devices()):
        if d["name"] == name and d["hostapi"] == sd.default.hostapi and d[f"max_{kind}_channels"] > 0:
            return i
    return None


def test(mic: str, out: str) -> bool:
    input("\nTEST: Enter dabao, phir 3 second mic mein bolo...")
    try:
        audio = sd.rec(3 * RATE, samplerate=RATE, channels=1, dtype="int16",
                       device=device_index(mic, "input"))
        sd.wait()
        level = int(abs(audio).max())
        print(f"Mic level: {level}" + ("  (bahut dheema - mic on hai? paas se bolo)" if level < 500 else "  OK"))
        print("Ab earphones mein apni awaaz suno...")
        sd.play(audio, samplerate=RATE, device=device_index(out, "output"))
        sd.wait()
    except Exception as e:
        print(f"Error: {e}")
        return False
    return input("Apni awaaz sunai di? (y/n): ").strip().lower() == "y"


def main():
    print("MARK L - Mic aur Earphones select karo")
    while True:
        mic = pick("input", "MIC (awaaz kahan se aayegi)")
        out = pick("output", "EARPHONES / SPEAKER (awaaz kahan jayegi)")
        if test(mic, out):
            break
        print("\nKoi baat nahi, dobara chuno.")

    cfg = {}
    try:
        cfg = json.loads(CONFIG.read_text(encoding="utf-8"))
    except Exception:
        pass
    cfg["input_device"], cfg["output_device"] = mic, out
    CONFIG.parent.mkdir(exist_ok=True)
    CONFIG.write_text(json.dumps(cfg, indent=4), encoding="utf-8")
    print(f"\nSaved! Mic: {mic or 'Windows default'} | Output: {out or 'Windows default'}")
    print("Ab start.bat chalao. Badalna ho to choose_audio.bat dobara chalao.")


if __name__ == "__main__":
    main()
