@echo off
rem Double-click to start MARK L lite.
cd /d "%~dp0"
python main.py
if errorlevel 1 pause
