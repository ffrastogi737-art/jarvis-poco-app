@echo off
rem Double-click to install MARK L lite (Windows 10/11 64-bit).
cd /d "%~dp0"

rem "python --version" fails on the Microsoft Store stub too, unlike "where python".
python --version >nul 2>&1
if errorlevel 1 (
    echo Python not found. Installing Python 3.12 with winget...
    winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
    if errorlevel 1 (
        echo.
        echo Could not install Python automatically.
        echo Download Python 3.12 64-bit from https://www.python.org/downloads/
        echo During install tick "Add python.exe to PATH", then run install.bat again.
        pause
        exit /b 1
    )
    echo.
    echo Python installed. Close this window and double-click install.bat again.
    pause
    exit /b 0
)

python -c "import sys; sys.exit(sys.version_info < (3, 11))"
if errorlevel 1 (
    echo Your Python is older than 3.11. Install Python 3.12 from https://www.python.org/downloads/
    pause
    exit /b 1
)

echo Installing MARK L requirements. This can take 10-20 minutes on a slow laptop...
python setup.py
if errorlevel 1 (
    echo.
    echo Setup failed. Take a photo of the error above and send it to Claude.
    pause
    exit /b 1
)

echo.
echo Done! Step 1: double-click choose_audio.bat to pick your mic and earphones.
echo Step 2: double-click start.bat to run MARK L.
echo On first start it asks for your free Gemini API key: https://aistudio.google.com/apikey
pause
