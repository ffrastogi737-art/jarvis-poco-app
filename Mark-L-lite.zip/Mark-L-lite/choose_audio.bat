@echo off
rem Double-click to choose the mic and earphones MARK L uses.
cd /d "%~dp0"
python choose_audio.py
pause
